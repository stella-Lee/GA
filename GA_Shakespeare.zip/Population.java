// Modified from Daniel Shiffman's http://natureofcode.com
// Genetic Algorithm, Evolving Shakespeare

// A class to describe a population of virtual organisms
// In this case, each organism is just an instance of a DNA object

import java.lang.String;
import java.util.*;

class Population {
    DNA[] population;// Array to hold the current population
    Vector<DNA> matingPool;// ArrayList which we will use for our "mating pool". In accordance with the fitness value, the number of entries for the population[i] is decided. Refer the explanation of Daniel.
    int generations;// Number of generations
    boolean finished;// Are we finished evolving?
    String target; // Target phrase
    int fitness;
    String best;
    double mutationRate;// Mutation rate
    int perfectScore;

    public Population(String p, double m, int num) {//initializatiom
        this.population = new DNA[num];
        this.generations = 0; 
        this.finished = false; 
        this.target = p;
        this.mutationRate = m; 
        this.perfectScore = 1;

        for (int i = 0; i < num; i++) {
            DNA dna = new DNA(this.target.length());
            this.population[i] = dna;
        }
        this.calcFitness();
  }

  // Fill our fitness array with a value for every member of the population
    public void calcFitness() {
        for (int i = 0; i < this.population.length; i++) {
            this.population[i].calcFitness(target);
        }
    }

    // // Generate a mating pool
    public void naturalSelection() {
        // Clear the ArrayList
        this.matingPool = new Vector<DNA>();

        double maxFitness = 0;
        for (int i = 0; i < this.population.length; i++) {
            if (this.population[i].fitness > maxFitness) {
                maxFitness = this.population[i].fitness;
            }
        }

        // Based on fitness, each member will get added to the mating pool a certain number of times
        // a higher fitness = more entries to mating pool = more likely to be picked as a parent
        // a lower fitness = fewer entries to mating pool = less likely to be picked as a parent
        for (int i = 0; i < this.population.length; i++) {
            // double fitness = map(this.population[i].fitness, 0, maxFitness, 0, 1); map?
            int n = (int) (this.population[i].fitness * 100); // Arbitrary multiplier, we can also use monte carlo method
            for (int j = 0; j < n; j++) { // and pick two random numbers
                this.matingPool.add(this.population[i]);
            }
        }
    }

    // Create a new generation
     public void generate() {
    // Refill the population with children from the mating pool
        for (int i = 0; i < this.population.length; i++) {
            int a = (int) (Math.random()*this.matingPool.size());
            int b = (int) (Math.random()*this.matingPool.size());
            DNA partnerA = this.matingPool.get(a);
            DNA partnerB = this.matingPool.get(b);
            DNA child = partnerA.crossover(partnerB);
            child.mutate(this.mutationRate);
            this.population[i] = child;
        }
        this.generations++;
  }

    public String getBest() {
        return this.best;
    }

    // Compute the current "most fit" member of the population
    public void evaluate() {
        double worldrecord = 0.0;
        int index = 0;
        for (int i = 0; i < this.population.length; i++) {
            if (this.population[i].fitness > worldrecord) {
                index = i;
                worldrecord = this.population[i].fitness;
            }
        }
        this.best = this.population[index].getPhrase();
        if (worldrecord == this.perfectScore) {
            this.finished = true;
        }
    }

    public boolean isFinished() {
        return this.finished;
    }

    public int getGenerations() {
        return this.generations;
    }

    // Compute average fitness for the population
    public double getAverageFitness() {
        double total = 0;
        for (int i = 0; i < this.population.length; i++) {
        total += this.population[i].fitness;
        }
        return total / (this.population.length);
    }

    public String allPhrases() {
        String everything = "";

        int displayLimit;
        if (this.population.length<50)
            displayLimit=this.population.length;
        else
            displayLimit=50;

        for (int i = 0; i < displayLimit; i++) {
        everything += this.population[i].getPhrase() + "\n";
        }
        return everything;
    }
}