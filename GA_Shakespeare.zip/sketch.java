/// Modified from Daniel Shiffman's http://natureofcode.com

// Genetic Algorithm, Evolving Shakespeare

// Demonstration of using a genetic algorithm to perform a search


import java.lang.String;

public class sketch{
    public static void main(String[] args) {
        String target;
        int popmax;
        double mutationRate;
        Population population;
        String bestPhrase;
        String allPhrases;
        String stats;
   
        bestPhrase = "Best phrase:";
        allPhrases = "All phrases:";
        stats = "Stats:";
        
        // setup()
        target = "To be or not to be.";
        popmax = 200;//the more population, the faster coveragence. But there is trade-off
        mutationRate = (double) 0.01;//Without mutation same chromosomes are gnerated  

        //  # Step 1: The Population
        //    # Create an empty population (an array or ArrayList)
        //    # Fill it with DNA encoded objects (pick random values to start)
        // Create a population with a target phrase, mutation rate, and population max
        population = new Population(target, mutationRate, popmax);
        //  # Step 1: Selection
        //    # Create an empty mating pool (an empty ArrayList)
        //    # For every member of the population, evaluate its fitness based on some criteria / function,
        //      and add it to the mating pool in a manner consistant with its fitness, i.e. the more fit it
        //      is the more times it appears in the mating pool, in order to be more likely picked for reproduction.

        //  # Step 2: Reproduction Create a new empty population
        //    # Fill the new population by executing the following steps:
        //       1. Pick two "parent" objects from the mating pool.
        //       2. Crossover -- create a "child" object by mating these two parents.
        //       3. Mutation -- mutate the child's DNA based on a given probability.
        //       4. Add the child object to the new population.
        //    # Replace the old population with the new population
        //
        //   # Rinse and repeat
        while (!(population.isFinished())) {   
            population.naturalSelection();
            population.generate();
            population.calcFitness();    
            population.evaluate();
        } 

        String answer = population.getBest();
        bestPhrase = bestPhrase + answer;
        allPhrases = allPhrases + population.allPhrases();
        System.out.println(bestPhrase);
        System.out.println(stats);
        System.out.println("total generations:     " + population.getGenerations());
        System.out.println("average fitness:       " + population.getAverageFitness());
        System.out.println("total population:      " + popmax);
        System.out.println("mutation rate:         " + (int) (mutationRate * 100) + "%");
        System.out.println(allPhrases);
    }
}