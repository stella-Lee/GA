// Modified from Daniel Shiffman's http://natureofcode.com
// Genetic Algorithm, Evolving Shakespeare

// A class to describe a pseudo-DNA, i.e. genotype
//   Here, a virtual organism's DNA is an array of character.
//   Functionality:
//      -- convert DNA into a string
//      -- calculate DNA's "fitness"
//      -- mate DNA with another set of DNA
//      -- mutate DNA


// Constructor (makes a random DNA)
class DNA {
    char[] genes;
    double fitness;
    public DNA(int num){
    // The genetic sequence
        this.genes = new char[num];
        for (int i = 0; i < num; i++) {
            this.genes[i] = newChar(); // Pick from range of chars
        }
    } 

  // Converts character array to a String
    String getPhrase() {
        return String.valueOf(this.genes);
    }

  // Fitness function (returns floating point % of "correct" characters)
    void calcFitness(String target) {
        double score = 0;
        for (int i = 0; i < this.genes.length; i++) {
        if (this.genes[i]==target.charAt(i)) {
            score++;
        }
        }
        this.fitness = score/target.length();
    }
    
    public char newChar() {
        int c = (int) (Math.random()*59+63);        
        if (c == 63) c = 32;//공백
        if (c == 64) c = 46;//"."
      
        return (char) c;
    }
    // Crossover
    DNA crossover(DNA partner) {
    // A new child
        DNA child = new DNA(this.genes.length);
        int midpoint = (int)(Math.random()*this.genes.length); // Pick a midpoint randomly

        // Half from one, half from the other
        for (int i = 0; i < this.genes.length; i++) {
            if (i > midpoint) 
                child.genes[i] = this.genes[i];
            else 
                child.genes[i] = partner.genes[i];
        }

        return child;
  }

  // Based on a mutation probability, picks a new random character
    public void mutate(double mutationRate) {
        for (int i = 0; i < this.genes.length; i++) {
            if (Math.random()*1 < mutationRate) {
                this.genes[i] = newChar();
            }
    }
  }
}