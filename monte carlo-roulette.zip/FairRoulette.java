public class FairRoulette{
   int[] pockets;
   int ball;
   int pocketOdds;
    public FairRoulette(){
        pockets = new int[37];
        for(int i=1;i<37;i++){
            pockets[i]=i;
        }
        // ball = NULL;
        this.pocketOdds = pockets.length-1;
    }
    public void spin(){
        this.ball = (int) (Math.random()*36)+1;
        // System.out.println(ball);
    }
    public int betPocket(int pocket, int amt){
        if(pocket == this.ball)
            return amt*this.pocketOdds;
        else
            return -amt;
    }
    public String nameRoulette(){
        return "FairRoulette";
    }
    // public double playRoulette(FairRoulette game, int numSpins, int pocket, int bet, boolean toPrint){
    //     int totPocket = 0;
    //     for(int i=1;i<=numSpins;i++){
    //         game.spin();
    //         totPocket += game.betPocket(pocket, bet);
    //     }
    //     if(toPrint){
    //         System.out.println(numSpins + "spins of " + game.nameRoulette());
    //         System.out.println("Expected return betting"+pocket+"="+100*totPocket/numSpins+"%");
    //     }
    //     return (totPocket/numSpins);
    // }
}