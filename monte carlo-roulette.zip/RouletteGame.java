public class RouletteGame{
    public static void main(String[] args){
        FairRoulette game = new FairRoulette();
        int[] numSpins ={100, 1000000};
        for(int i=0;i<2;i++){
            for(int j=0;j<3;j++){
                playRoulette(game, numSpins[i], 2, 1, true);
            }
        }
    }
    
    public static double playRoulette(FairRoulette game, int numSpins, int pocket, int bet, boolean toPrint){
        int totPocket = 0;
        for(int i=1;i<=numSpins;i++){
            game.spin();
            totPocket += game.betPocket(pocket, bet);
        }
        if(toPrint){
            System.out.println(numSpins + " spins of " + game.nameRoulette());
            System.out.println("Expected return betting"+pocket+" = "+100*totPocket/numSpins+"%");
        }
        return (totPocket/numSpins);
    }
}