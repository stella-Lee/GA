runif(n=1000, min=0, max=1)
random.uniform.1000 = runif(n=100000, min=0, max=1)
#historam of 1000 uniform random number
hist(random.uniform.1000)
#if we want to look at 100 draws from a normal distribution with mean=5 and sd=2
random.normal.100 = rnorm(n=100, mean=5, sd=2)
#par allows us to modify low-level plotting function. 
#in this case changing the graphical device(the palette) to have 3 rows and 1 column,
#so, we can put three plots on it.
par(mfrow=c(3,1))
plot(random.normal.100)
boxplot(random.normal.100)
hist(random.normal.100)
#Let's look at some summary statistics from this simulation
mean(random.normal.100)
sd(random.normal.100)
#while the mean and sd are close to the values we inputted, they are not exactly 5, & 2

#let's repeat this experiment a few times
random.normal.100.1 = rnorm(100, 5,2)
random.normal.100.2 = rnorm(100, 5,2)
random.normal.100.3 = rnorm(100, 5,2)
random.normal.100.4 = rnorm(100, 5,2)
par(mfrow=c(2,2))
hist(random.normal.100.1)
hist(random.normal.100.2)
hist(random.normal.100.3)
hist(random.normal.100.4)

mean(random.normal.100.1)
mean(random.normal.100.2)
mean(random.normal.100.3)
mean(random.normal.100.4)
# All close to, but not exactly equal to 5.

#### more efficient performing the simulation
random.normal.100.rep = replicate(n=4, rnorm(100,5,2)) 
# And if we want to call from the rnorm function more than 4 times, 
#we just change the n= in the replicate function.
par(mfrow=c(2,2))
apply(X=random.normal.100.rep, MARGIN = 2, FUN = hist)
apply(X=random.normal.100.rep, MARGIN = 2, FUN = mean)
apply(random.normal.100.rep, 2,sd)
summary(random.normal.100.rep)

sd(apply(random.normal.100.rep,2,mean))

norm.sim.all.2=replicate(n=4, rnorm(100, 5,2))
summary(norm.sim.all.2)
apply(norm.sim.all.2,2, sd)
sd(apply(norm.sim.all.2,2,mean))

#Let's repeat this experiment with lower sample size(say 25). What happens to the spread?
norm.sim.all.3=replicate(n=4, rnorm(25, 5,2))
summary(norm.sim.all.3)
apply(norm.sim.all.3,2, sd)
sd(apply(norm.sim.all.3,2,mean))

#How about if we have much larger sampel size (say 1000)
norm.sim.all.4=replicate(n=4, rnorm(1000, 5,2))
summary(norm.sim.all.4)
apply(norm.sim.all.4,2, sd)
sd(apply(norm.sim.all.4,2,mean))

sd(apply(norm.sim.all.2, 2, mean))#100
sd(apply(norm.sim.all.3,2,mean))#25
sd(apply(norm.sim.all.4,2,mean))#1000
sd(apply(norm.sim.all.2,2,sd))#100
sd(apply(norm.sim.all.3,2,sd))#25
sd(apply(norm.sim.all.4,2,sd))#1000
par(mfrow=c(3,1))
hist(norm.sim.all.2)
hist(norm.sim.all.3)
hist(norm.sim.all.4)

mean(norm.sim.all.2)
mean(norm.sim.all.3)
mean(norm.sim.all.4)

#We have just learned about monte carlo method. When we perform simulations from that distributions,
#as our n increase we will get closer to the expected value (which in this case we provided)

#Instead of simulating just a mean and sd, let's specify something more interesting.
#How about a regression? Y=N(a+b*x, sd)

par(mfrow=c(2,2))
a=5
b=0.7
x=seq(2,20)
y_fixed=a+b*x
plot(y_fixed=x, main="Deterministic Component of the model")
abline(a=5, b=0.7)
