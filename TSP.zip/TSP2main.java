public class TSP2main{
    public static void main(String[] args){
        int popSize = 100;
        int tCities = 12;
        double mutationRate=0.2;
        double recordDistance;
        TSPPop bestEver;
        TSPPop[] tsp = new TSPPop[popSize];
        // ArrayList<TSPPop> tsp = new ArrayList<TSPPop>();  
        tsp[0] = new TSPPop(tCities, popSize, 20, 200, mutationRate);
        
        recordDistance = tsp[0].fitness;
        bestEver = tsp[0];

        for(int i = 1; i<popSize; i++){//generate population
            tsp[i] = shuffle(tsp[i-1], 10);
            tsp[i].fitness = tsp[i].calcDistance(tsp[i].cities);
        }

        int generation=0;
        while(generation<20){
            for(int i = 0; i<popSize;i++){//find best solution
                if (tsp[i].fitness < recordDistance) {
                    recordDistance = tsp[i].fitness;
                    System.out.println(recordDistance);
                    bestEver = tsp[i];
                }
            }

            double maxFitness=Double.MIN_VALUE;//find maximum fitness

            for(int i=0;i<tsp.length;i++){
                if(maxFitness<tsp[i].fitness){
                    maxFitness = tsp[i].fitness;
                }
            }
        
            for(int i=0;i<popSize;i++){
                int chosen = tsp[i].pickOne(tsp, maxFitness);//generate new generation
                tsp[chosen].cities = tsp[i].mutate(tsp[chosen].cities);
                tsp[chosen].fitness = tsp[chosen].calcDistance(tsp[chosen].cities);  
            }
        }
        generation++;
    }
        
    public static TSPPop shuffle(TSPPop a, int num){//generate randomly initial population 
        for(int i=0;i<num;i++){
            int indexA = (int) Math.floor(Math.random()*a.cities.length);
            int indexB = (int) Math.floor(Math.random()*a.cities.length);
            TSP1 temp1;
            temp1=a.cities[indexA];
            a.cities[indexA] = a.cities[indexB];
            a.cities[indexB] = temp1;
        }
        return a;
    }    
}
