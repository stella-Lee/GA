import java.util.ArrayList;

public class TSPPop{
    TSP1[] cities;
    // TSPop[] cityOrder;
    double fitness;
    double mutationRate;
    int numOfPop;
    int totalCities;
    int width;
    int height;
    double recordDistance;

    public TSPPop(int tCities, int pop, int w, int h, double mutRate){
        totalCities = tCities;
        numOfPop = pop;
        width=w;
        height=h;
        mutationRate = mutRate;
        cities = new TSP1[totalCities];

        for (int i = 0; i < totalCities; i++) {
            cities[i] = new TSP1();
            cities[i].x =(int) Math.floor(Math.random()*width)+1;
            cities[i].y = (int) Math.floor(Math.random()*height)+1;
        }
        fitness = this.calcDistance(cities);

    }

    public double calcDistance(TSP1[] points) {
        double sum = 0.0;
        for(int i = 0; i<points.length-1;i++){
            double d = dist(points[i].x,points[i].y, points[i+1].x, points[i+1].y);
        
            sum += d;
        }
        return sum;
    }

    public double dist(int x, int y, int x1, int y1){
        return Math.sqrt(Math.pow(Math.abs(x1-x), 2) + Math.pow(Math.abs(y1-y), 2));        
    }

    public int pickOne(TSPPop[] tsp, double maxV){    
        int besafe=0;
        while(true){
            int index = (int) Math.floor(Math.random()*tsp.length);//choose 1 of population
            double r = Math.random()*maxV;//generate fitness
            if(r<tsp[index].fitness){//if fitness value of selected population select it for crossover => means population that has more larger fitness value can be selected more frequently.
                return index;
            }
            besafe++;
            if(besafe>1000)
                return 1;
        } 
    }

    // public void crossOver()
    public TSP1[] mutate(TSP1[] order) {
        for (int i = 0; i < order.length; i++) {
            if (Math.random()*1 < mutationRate) {//mutation rate = 0.1
                int indexA = (int) Math.floor(Math.random()*order.length);
                int indexB = (indexA + 1) % order.length;
                TSP1 temp1;
                temp1=order[indexA];
                order[indexA] = order[indexB];
                order[indexB] = temp1;
            }
        }
        return order;
    }

}