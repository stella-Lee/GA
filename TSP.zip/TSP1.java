public class TSP1{
    public int x;
    public int y;
    public TSP1(){
        this.x=1;
        this.y=1;
    }
}