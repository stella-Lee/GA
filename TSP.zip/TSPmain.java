public class TSPmain{
    public static void main(String[] args){
        int totalCities = 5;
        TSP1[] cities = new TSP1[totalCities];
        int[] cityOrder = new int[totalCities];
        int width = 50;
        int height = 50;
        double recordDistance;
        TSP1[] bestEver = new TSP1[totalCities];

        for (int i = 0; i < totalCities; i++) {
            cities[i] = new TSP1();
            cities[i].x =(int) Math.floor(Math.random()*width)+1;
            cities[i].y = (int) Math.floor(Math.random()*height)+1;
            cityOrder[i] = i;
        }

        double d = calcDistance(cities);
        recordDistance = d;
        bestEver = cities;
        for(int i=0;i<cities.length;i++){
            // System.out.print("("+bestEver[i].x + "," + bestEver[i].y + ") ");
            System.out.print(cityOrder[i] + ", ");
        }
        System.out.println();
        int cnt=0;
        while(cnt<100){
            int i = (int) (Math.random()*cities.length);
            int j = (int) (Math.random()*cities.length);
            swap(cities, i,j);
            int temp1 = cityOrder[i];
            cityOrder[i] = cityOrder[j];
            cityOrder[j] = temp1;
            d = calcDistance(cities);
            if (d < recordDistance) {
                recordDistance = d;
                System.out.println(recordDistance);
                bestEver = cities;
                for(int k=0;k<cities.length;k++){
                    // System.out.print("("+bestEver[i].x + "," + bestEver[i].y + ") ");
                    System.out.print(cityOrder[k] + ", ");
                }
                System.out.println();
            }
            cnt++;
        }
    }

    public static void swap(TSP1[] a, int i, int j) {
        TSP1 temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    static double calcDistance(TSP1[] points) {
        double sum = 0.0;
        for (int i = 0; i < points.length - 1; i++) {
            double d = dist(points[i].x, points[i].y, points[i + 1].x, points[i + 1].y);
            sum += d;
        }
        return sum;
    }

    static double dist(int x, int y, int x1, int y1){
        return Math.sqrt(Math.pow(Math.abs(x1-x), 2) + Math.pow(Math.abs(y1-y), 2));        
    }
}