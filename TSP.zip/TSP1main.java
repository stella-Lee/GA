public class TSP1main{
    public static void main(String[] args){
        int totalCities = 10;
        int popSize = 100;
        TSP1[] cities = new TSP1[totalCities];
        int[] cityOrder = new int[totalCities];
        int[][] population = new int[popSize][totalCities];
        // int[][] newPopulation = new int[popSize][totalCities];
        double[] fitness = new double[popSize];
        int width = 50;
        int height = 50;
        double recordDistance;
        TSP1[] bestEver = new TSP1[totalCities];

        for (int i = 0; i < totalCities; i++) {
            cities[i] = new TSP1();
            cities[i].x =(int) Math.floor(Math.random()*width)+1;
            cities[i].y = (int) Math.floor(Math.random()*height)+1;
            cityOrder[i] = i;
        }

        double d = Double.MAX_VALUE;
        recordDistance = d;
        bestEver = cities;
        for(int i=0;i<cities.length;i++){
            // System.out.print("("+bestEver[i].x + "," + bestEver[i].y + ") ");
            System.out.print(cityOrder[i] + ", ");
        }
        System.out.println();

        for(int i = 0; i<popSize; i++){//generate population
            shuffle(cityOrder, 10);
            for(int j=0;j<totalCities;j++){
                population[i][j]=cityOrder[j];
            }
        }

        int generation=0;
        while(generation<50){
            for(int i = 0; i<popSize;i++){//calculate fitness
                d = calcDistance(cities, population[i]);
                if (d < recordDistance) {
                    recordDistance = d;
                    System.out.println(recordDistance);
                    bestEver = cities;
                }
                fitness[i] = d;
            }

            // System.out.println(recordDistance);

            double maxFitness=Double.MIN_VALUE;//find maximum fitness
            for(int i=0;i<population.length;i++){
                if(maxFitness>fitness[i]){
                    maxFitness = fitness[i];
                }
            }
            for(int i=0;i<popSize;i++){
                int chosen = pickOne(fitness, maxFitness);//generate new generation
                // System.out.println(chosen);
                // int chosen2 = pickOne(fitness, maxFitness);
                mutate(population[chosen]);
                // mutate(population[chosen2]);       
            }
        }
        generation++;
    }

    public static int pickOne(double[] fit, double maxV){    
        int besafe=0;
        while(true){
            int index = (int) Math.floor(Math.random()*fit.length);//choose 1 of population
            double r = Math.random()*maxV;//generate fitness
            // System.out.println(r);
            if(r<fit[index]){//if fitness value of selected population select it for crossover => means population that has more larger fitness value can be selected more frequently.
                return index;
            }
            besafe++;
            if(besafe>10000)
                return 1;
        } 
    }

    public static void mutate(int[] order) {
        for (int i = 0; i < order.length; i++) {
            if (Math.random()*1 < 0.1) {//mutation rate = 0.1
                int indexA = (int) Math.floor(Math.random()*order.length);
                int indexB = (indexA + 1) % order.length;
                int temp1;
                temp1=order[indexA];
                order[indexA] = order[indexB];
                order[indexB] = temp1;
            }
        }
    }
        
    public static void shuffle(int[] a, int num){//generate randomly initial population 
        for(int i=0;i<num;i++){
            int indexA = (int) Math.floor(Math.random()*a.length);
            int indexB = (int) Math.floor(Math.random()*a.length);
            int temp1;
            temp1=a[indexA];
            a[indexA] = a[indexB];
            a[indexB] = temp1;
        }
    }
    public static void swap(TSP1[] a, int i, int j) {
        TSP1 temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    static double calcDistance(TSP1[] points, int[] pop) {
        double sum = 0.0;
        // for (int i = 0; i < points.length - 1; i++) {
        //     double d = dist(points[i].x, points[i].y, points[i + 1].x, points[i + 1].y);
        //     sum += d;
        // }
        // for(int i=0;i<points.length;i++)
        //     System.out.print(pop[i]);
        // System.out.println();
        for(int i = 0; i<points.length-1;i++){
            double d = dist(points[pop[i]].x,points[pop[i]].y, points[pop[i + 1]].x, points[pop[i + 1]].y);
            sum += d;
        }
        return sum;
    }

    static double dist(int x, int y, int x1, int y1){
        return Math.sqrt(Math.pow(Math.abs(x1-x), 2) + Math.pow(Math.abs(y1-y), 2));
        
    }
}

        // function draw() {
    // background(0);
    // fill(255);
    // for (var i = 0; i < cities.length; i++) {
    //     ellipse(cities[i].x, cities[i].y, 8, 8);
    // }

    // stroke(255);
    // strokeWeight(1);
    // noFill();
    // beginShape();
    // for (var i = 0; i < cities.length; i++) {
    //     vertex(cities[i].x, cities[i].y);
    // }
    // endShape();

    // stroke(255, 0, 255);
    // strokeWeight(4);
    // noFill();
    // beginShape();
    // for (var i = 0; i < cities.length; i++) {
    //     vertex(bestEver[i].x, bestEver[i].y);
    // }
    // endShape();
